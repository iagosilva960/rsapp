package com.gruporsbrasil.guincho;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
