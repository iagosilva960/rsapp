# Informações do Grupo RS Brasil

## Serviços:
- Terraplanagem
- Reciclagem
- Guincho 24hrs: Prestam serviço de guincho e autossocorro 24 horas para carros pequenos, caminhões, máquinas e cargas em geral. Contam com guinchos leves e plataformas de até 11 metros, garantindo segurança e agilidade em qualquer situação, inclusive emergências e transporte programado.
- Transporte de Cargas
- Assessoria Ambiental
- Transbordo de Carga

## Contato:
Av. Alcides Lacerda, 1220 - Arivaldo Reis, Eunápolis - BA, 45826-204
Tel: (73)9 9942-2663

## Identidade Visual:
O site apresenta um logo com 'GRUPO RS' em verde e azul. As cores predominantes no site são azul escuro, verde e branco. Há imagens de máquinas pesadas, caminhões de guincho e áreas de reciclagem. O estilo é funcional e direto, com foco nos serviços. A fonte utilizada parece ser sans-serif, limpa e legível.

